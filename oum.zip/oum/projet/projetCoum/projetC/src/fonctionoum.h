#ifndef _fonction_h
#define _fonction_h
#include <stdio.h>
#include <stdlib.h>


typedef struct etudiant_heberge
{
char nom[20];
char prenom[20];
char identifiant[20];
char classe[10];
char sexe [10];
char num_telephone[20];
char nom_parent[20];
char prenom_parent[20];
char num_telephone_parent[20];
char foyer[10]; 
char niveau[20];
char num_de_la_chambre[10];
char mail[39];
char cin[39];
char pw[39]; 
char role[39];
char numero[39];
char role3[39];
char id[39];
char user[39];
} etudiant_heberge;


GtkTreeIter iter;

etudiant_heberge eh;

int ajouter_etudiant(etudiant_heberge eh1);
void modifier_etudiant(etudiant_heberge eh1);
void supprimer_etudiant(char identifiant[]);
void rechercher_etudiant ();
void afficher_tout(GtkTreeView *liste);
int etudiant_par_etage(char *niveau ,char *foyer);
//void ajouter( char Nom[], char Prenom[], char Utilisateur[], char Mot_De_Passe[]);
int verifier( char Utilisateur[], char Mot_De_Passe[]);
//int verif1( char identifiant[]);
#endif

