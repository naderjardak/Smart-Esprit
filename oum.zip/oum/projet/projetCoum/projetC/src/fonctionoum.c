#ifdef HAVE_CONFIG_H
#include <config.h>

#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "fonctionoum.h"


enum
{
NOM,
PRENOM,
IDENTIFIANT,
CLASSE,
SEXE,
NUMT,
NOMP,
PRENOMP,
NUMTP,
FOYER,
NIVEAU,
NUMCH,

COLUMNO
};



int ajouter_etudiant(etudiant_heberge eh1)
{
etudiant_heberge eh;
FILE *f;
int found=0;

f=fopen("hebergement.txt","a") ;

if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF) 
{
if (strcmp(eh.identifiant ,eh1.identifiant)==0) 
{
found=1;
break;
}
}
}
if (found==0)
{
fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh1.nom,eh1.prenom,eh1.identifiant,eh1.classe,eh1.sexe,eh1.num_telephone,eh1.nom_parent,eh1.prenom_parent,eh1.num_telephone_parent,eh1.foyer,eh1.niveau,eh1.num_de_la_chambre) ;
fclose(f);
return 1;
}

return 0;
}



void modifier_etudiant (etudiant_heberge eh1)
{
etudiant_heberge eh;
FILE *f;
FILE *f1;
f=fopen("hebergement.txt","a+");
f1=fopen("hebergement1.txt","a+");
if (f!= NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF) 
{
if (strcmp(eh1.identifiant,eh.identifiant)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh1.nom,eh1.prenom,eh1.identifiant,eh1.classe,eh1.sexe,eh1.num_telephone,eh1.nom_parent,eh1.prenom_parent,eh1.num_telephone_parent,eh1.foyer,eh1.niveau,eh1.num_de_la_chambre) ;
}
else
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre) ;
}
fclose(f1);
fclose(f);
remove("hebergement.txt");
rename ("hebergement1.txt","hebergement.txt");
}
}



void supprimer_etudiant (char identifiant[])
{
etudiant_heberge eh;
FILE *f;
FILE *f1 ;
f1 =NULL;
f=fopen("hebergement.txt","r") ;
f1=fopen("hebergement1.txt","a");
if (f!= NULL)
{

while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF)
{
if (strcmp(identifiant,eh.identifiant)!=0)
{


fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre) ;
}
}
}


fclose(f);
fclose(f1);
remove("hebergement.txt");
rename("hebergement1.txt","hebergement.txt");
}



void rechercher_etudiant ()
{


}



void afficher_tout(GtkTreeView *liste) 
{

	etudiant_heberge eh;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	
	store=NULL;
	FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{

		renderer = gtk_cell_renderer_text_new();	
		column = gtk_tree_view_column_new_with_attributes("identifiant",renderer, "text",IDENTIFIANT, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom",renderer, "text",NOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom",renderer, "text",PRENOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("classe",renderer, "text",CLASSE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe",renderer, "text",SEXE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("num telephone",renderer, "text",NUMT, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom parent",renderer, "text",NOMP, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom parent",renderer, "text",PRENOMP, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("num de telephone de parent",renderer, "text",NUMTP, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("foyer",renderer, "text",FOYER, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("niveau",renderer, "text",NIVEAU, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("num de la chambre",renderer, "text",NUMCH, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		
	store=gtk_list_store_new(COLUMNO, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f=fopen("hebergement.txt","r");

if (f==NULL)
{
return;
}
else
{
f=fopen("hebergement.txt","a+");
}
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,IDENTIFIANT,eh.identifiant, NOM,eh.nom,PRENOM,eh.prenom,CLASSE,eh.classe,SEXE,eh.sexe,NUMT,eh.num_telephone,NOMP,eh.nom_parent,PRENOMP,eh.prenom_parent,NUMTP,eh.num_telephone_parent,FOYER,eh.foyer,NIVEAU,eh.niveau,NUMCH,eh.num_de_la_chambre,-1);
		}
		fclose(f);
		}
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste),GTK_TREE_MODEL (store));
		g_object_unref(store);
}


int etudiant_par_etage(char *niveau ,char *foyer)
{
FILE *f ;
f=fopen("hebergement.txt","a+");
int i=0;
if (f!=NULL)
{
while (fscanf(f,"%s %s  \n",eh.foyer,eh.niveau)!=EOF)
{
if(strcmp(foyer,eh.foyer)==0 && strcmp(niveau,eh.niveau)==0)
{

i++;

}
}
printf("le nb des etudiants dans l'etage %s du foyer %s est = %d",eh.niveau, eh.foyer,i);
}
fclose(f);

}










int verif( char identifiant[])
{
etudiant_heberge eh;
int t=0;
FILE *f=NULL;
char id[20];


f=fopen("hebergement.txt","r");
if(f!=NULL)
while (fscanf(f,"%s",id)!=EOF)
{
if(strcmp(id,eh.identifiant)==0)
t=1;

fclose(f);

}
return t;
}






