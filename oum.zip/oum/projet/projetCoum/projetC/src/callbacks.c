#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

#include "fonctionoum.h"






void
on_buttonajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajout,*tache;
windowajout=create_windowajout();
gtk_widget_show (windowajout);
tache=lookup_widget(button,"windowtache");
gtk_widget_destroy(tache);
}



void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *windowmodif,*tache;

windowmodif=create_windowmodif();
gtk_widget_show (windowmodif);
tache=lookup_widget(button,"windowtache");
gtk_widget_destroy(tache);
}



void
on_buttonsup_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowsup,*tache;
windowsup=create_windowsup();
gtk_widget_show (windowsup);
tache=lookup_widget(button,"windowtache");
gtk_widget_destroy(tache);
}


void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrech,*tache;
windowrech=create_windowrech();
gtk_widget_show (windowrech);
tache=lookup_widget(button,"windowtache");
gtk_widget_destroy(tache);
}


void
on_buttonaff_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaff,*windowtache,*treeviewaff;
windowtache=lookup_widget(button,"windowtache");
gtk_widget_destroy(windowtache);
windowaff=lookup_widget(button,"windowaff");
windowaff=create_windowaff();
gtk_widget_show (windowaff);
treeviewaff=lookup_widget(windowaff,"treeviewaff");
afficher_tout(treeviewaff);
}





void
on_buttonrech1_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *iden;
char id [20];
char ch1[200];

iden = lookup_widget(button,"entryrech");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(iden)));

iden = lookup_widget(button,"oumlabrech");


	
FILE *f;

f=fopen("hebergement.txt","r");

if (f==NULL)
{
return;
}
else
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF)
{
if(strcmp(eh.identifiant,id)==0)
{
sprintf(ch1,"%s %s %s %s %s %s %s %s %s %s %s %s ",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre);
}
}
fclose(f);
gtk_label_set_text(GTK_LABEL(iden),ch1);
	
}


void
on_buttonquitter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonsup1_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *identifiant, *windowsup;
char identifiant1[30];
identifiant = lookup_widget(button,"entrysup");
strcpy(identifiant1, gtk_entry_get_text(GTK_ENTRY(identifiant)));
supprimer_etudiant(identifiant1);
}



void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
GtkWidget *sexe,*nom,*prenom,*identifiant,*classe,*num_telephone,*nom_parent,*prenom_parent,*num_telephone_parent,*foyer,*niveau,*num_de_la_chambre, *windowajout;



sexe=lookup_widget(togglebutton,"comboboxsexe");
strcpy(eh.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(sexe)));



nom= lookup_widget(togglebutton,"entrynomeh");
prenom = lookup_widget(togglebutton,"entryprenomeh");
identifiant = lookup_widget(togglebutton,"entryideneh");
classe = lookup_widget(togglebutton,"entryclasseeh");
num_telephone = lookup_widget(togglebutton,"entrynumeh");
nom_parent = lookup_widget(togglebutton,"entrynompareh");
prenom_parent = lookup_widget(togglebutton,"entryprenompareh");
num_telephone_parent = lookup_widget(togglebutton,"entrynumpareh");
foyer = lookup_widget(togglebutton,"entryfoyereh");
niveau = lookup_widget(togglebutton,"entryniveaueh");
num_de_la_chambre = lookup_widget(togglebutton,"entrynumchameh");


strcpy(eh.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(eh.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(eh.identifiant, gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(eh.classe, gtk_entry_get_text(GTK_ENTRY(classe)));
strcpy(eh.num_telephone, gtk_entry_get_text(GTK_ENTRY(num_telephone)));
strcpy(eh.nom_parent, gtk_entry_get_text(GTK_ENTRY(nom_parent)));
strcpy(eh.prenom_parent, gtk_entry_get_text(GTK_ENTRY(prenom_parent)));
strcpy(eh.num_telephone_parent, gtk_entry_get_text(GTK_ENTRY(num_telephone_parent)));
strcpy(eh.foyer, gtk_entry_get_text(GTK_ENTRY(foyer)));
strcpy(eh.niveau, gtk_entry_get_text(GTK_ENTRY(niveau)));
strcpy(eh.num_de_la_chambre, gtk_entry_get_text(GTK_ENTRY(num_de_la_chambre)));

ajouter_etudiant(eh);
}


int c=0;
void
on_radiobuttonf_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
c=1;
}


void
on_radiobuttonm_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
c=2;
}






void
on_treeviewaff_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

etudiant_heberge eh;
gchar nom;
gchar prenom;
gchar identifiant;
gchar classe;
gchar sexe;
gchar num_telephone;
gchar nom_parent;
gchar prenom_parent;
gchar num_telephone_parent;
gchar foyer;
gchar niveau;
gchar num_de_la_chambre;

GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&identifiant,3,&classe,4,&sexe,5,&num_telephone,6,&nom_parent,7,&prenom_parent,8,&num_telephone_parent,9,&foyer,10,&niveau,11,&num_de_la_chambre,-1);
strcpy(eh.nom, nom);
strcpy(eh.prenom, prenom);
strcpy(eh.identifiant, identifiant);
strcpy(eh.classe, classe);
strcpy(eh.sexe, sexe);
strcpy(eh.num_telephone, num_telephone);
strcpy(eh.nom_parent, nom_parent);
strcpy(eh.prenom_parent, prenom_parent);
strcpy(eh.num_telephone_parent, num_telephone_parent);
strcpy(eh.foyer, foyer);
strcpy(eh.niveau, niveau);
strcpy(eh.num_de_la_chambre, num_de_la_chambre);
afficher_tout(treeview);
}
}




void
on_buttonquitter2_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tache,*windowaff;
windowaff=lookup_widget(button,"windowaff");
gtk_widget_destroy(windowaff);
tache=create_windowtache();
gtk_widget_show(tache);

}


void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
treeview=lookup_widget(button,"treeviewaff");
afficher_tout(treeview);
}

void
on_oummodif_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *sexe,*nom,*prenom,*identifiant,*classe,*num_telephone,*nom_parent,*prenom_parent,*num_telephone_parent,*foyer,*niveau,*num_de_la_chambre, *windowajout;

nom= lookup_widget(button,"entrynomeh1");
prenom = lookup_widget(button,"entrypreeh1");
identifiant = lookup_widget(button,"entrymodif");
classe = lookup_widget(button,"entryclasseeh1");
num_telephone = lookup_widget(button,"entrynumeh1");
nom_parent = lookup_widget(button,"entrynompareeh1");
prenom_parent = lookup_widget(button,"entryprepareh1");
num_telephone_parent = lookup_widget(button,"entrynumpareh1");
foyer = lookup_widget(button,"entryfoyereh1");
niveau = lookup_widget(button,"entryniveh1");
num_de_la_chambre = lookup_widget(button,"entrynumchameh1");


strcpy(eh.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(eh.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(eh.identifiant, gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(eh.classe, gtk_entry_get_text(GTK_ENTRY(classe)));
strcpy(eh.num_telephone, gtk_entry_get_text(GTK_ENTRY(num_telephone)));
strcpy(eh.nom_parent, gtk_entry_get_text(GTK_ENTRY(nom_parent)));
strcpy(eh.prenom_parent, gtk_entry_get_text(GTK_ENTRY(prenom_parent)));
strcpy(eh.num_telephone_parent, gtk_entry_get_text(GTK_ENTRY(num_telephone_parent)));
strcpy(eh.foyer, gtk_entry_get_text(GTK_ENTRY(foyer)));
strcpy(eh.niveau, gtk_entry_get_text(GTK_ENTRY(niveau)));
strcpy(eh.num_de_la_chambre, gtk_entry_get_text(GTK_ENTRY(num_de_la_chambre)));

if (c==1)
strcpy(eh.sexe,"feminin");

else if(c==2)
strcpy(eh.sexe,"masculin");
modifier_etudiant (eh);
}


void
on_oumretmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *windowtache;
  windowtache = create_windowtache ();
  gtk_widget_show (windowtache);
}


void
on_oumretsupp_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *windowtache;
  windowtache = create_windowtache ();
  gtk_widget_show (windowtache);
}


void
on_oumretrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *windowtache;
  windowtache = create_windowtache ();
  gtk_widget_show (windowtache);
}


void
on_oumretaj_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *windowtache;
  windowtache = create_windowtache ();
  gtk_widget_show (windowtache);
}


void
on_treeviewoumrech_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
char id[3]="";
etudiant_heberge eh;
gchar nom;
gchar prenom;
gchar identifiant;
gchar classe;
gchar sexe;
gchar num_telephone;
gchar nom_parent;
gchar prenom_parent;
gchar num_telephone_parent;
gchar foyer;
gchar niveau;
gchar num_de_la_chambre;

GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&identifiant,3,&classe,4,&sexe,5,&num_telephone,6,&nom_parent,7,&prenom_parent,8,&num_telephone_parent,9,&foyer,10,&niveau,11,&num_de_la_chambre,-1);
strcpy(eh.nom, nom);
strcpy(eh.prenom, prenom);
strcpy(eh.identifiant, identifiant);
strcpy(eh.classe, classe);
strcpy(eh.sexe, sexe);
strcpy(eh.num_telephone, num_telephone);
strcpy(eh.nom_parent, nom_parent);
strcpy(eh.prenom_parent, prenom_parent);
strcpy(eh.num_telephone_parent, num_telephone_parent);
strcpy(eh.foyer, foyer);
strcpy(eh.niveau, niveau);
strcpy(eh.num_de_la_chambre, num_de_la_chambre);
rechercher_etudiant(id,treeview);
}
}






void
on_buttonnb_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *windowtache;
  windowtache = create_dashoum ();
  gtk_widget_show (windowtache);


}


void
on_check_niv_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ec1,*ec2,*ec3,*ec4,*ec5;

int k=0;	
int p1=0;
int p2=0;
int p3=0;
int p4=0;
int p5=0;

char ch;
char ch1[20];
char ch2[20];
char ch3[20];
char ch4[20];
char ch5[20];

ec1=lookup_widget(button,"c1");
ec2=lookup_widget(button,"c2");
ec3=lookup_widget(button,"c3");
ec4=lookup_widget(button,"c4");
ec5=lookup_widget(button,"c5");

	FILE *f;

  f=fopen("hebergement.txt","a+"); 
  while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF)
{
   

    if(eh.classe[0]=='1')
    k=1;
    if(eh.classe[0]=='2')
    k=2;
    if(eh.classe[0]=='3')
    k=3;
    if(eh.classe[0]=='4')
    k=4;
    if(eh.classe[0]=='5')
    k=5;
   
	
         if(k==1)
	 p1++;
    else if(k==2)
	 p2++;
   else if(k==3)
	 p3++;
   else if(k==4)
	 p4++;
   else 
         p5++;
}

sprintf(ch1,"%d",p1);
gtk_entry_set_text(ec1,ch1);

sprintf(ch2,"%d",p2);
gtk_entry_set_text(ec2,ch2);

sprintf(ch3,"%d",p3);
gtk_entry_set_text(ec3,ch3);

sprintf(ch4,"%d",p4);
gtk_entry_set_text(ec4,ch4);

sprintf(ch5,"%d",p5);
gtk_entry_set_text(ec5,ch5);

}




