#include <gtk/gtk.h>


void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_validaj_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_validmodif_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_validchercher_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_validsupprimer_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_man_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_fem_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeviewaffiche_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retouraffiche_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewaffiche_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_pannedb_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourpanne_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiserpanne_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_htreeviewpanne_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_hretourajout_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_hretourmodif_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_houschretour_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_hretoursupp_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_h_rech_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_h_rech_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_hboutonfum_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewfum_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retourfum_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiserfum_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_hpannemvt_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewpannemv_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retourpannemv_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiserpannemv_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_hpannetemp_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewpannetemp_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_actualiserpannetemp_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourpannetemp_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_hlogin_clicked                      (GtkButton       *button,
                                        gpointer         user_data);
