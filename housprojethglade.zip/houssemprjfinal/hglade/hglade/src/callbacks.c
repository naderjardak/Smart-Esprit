#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "hfonction.h"


void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windoww;
windoww=create_affichage();
gtk_widget_show(windoww);

GtkWidget *treeview;
windoww=lookup_widget(windoww,"treeviewaffiche");
afficher(windoww);

}


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_suppresion();
gtk_widget_show(window);
}


void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_founding();
gtk_widget_show(window);
}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_modification();
gtk_widget_show(window);
}


void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window;
window=create_AJOUT();
gtk_widget_show(window);
}




int l=0;
void
on_man_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
l=1;
}


void
on_fem_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
l=2;
}






void
on_validaj_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *window, *nom2, *prenom2, *cin2, *mail2, *user2, *num2, *spinbutton1,*pw1,*role1;


nom2 = lookup_widget (button , "nom");
prenom2 = lookup_widget (button , "prenom");
cin2 = lookup_widget (button , "cin");
mail2 = lookup_widget (button , "mail");
user2 = lookup_widget (button , "huserajout");
pw1= lookup_widget(button,"ajouter_pw_entry");
num2 = lookup_widget (button , "num");
spinbutton1=lookup_widget(button,"spinbutton1");
role1=lookup_widget(button,"ajouter_role_combobox");

int c;
c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
sprintf(s.id,"%d",c);
strcpy(s.nom, gtk_entry_get_text(GTK_ENTRY(nom2)));
strcpy(s.prenom, gtk_entry_get_text(GTK_ENTRY(prenom2)));
strcpy(s.cin, gtk_entry_get_text(GTK_ENTRY(cin2)));
strcpy(s.mail, gtk_entry_get_text(GTK_ENTRY(mail2)));
strcpy(s.user, gtk_entry_get_text(GTK_ENTRY(user2)));
strcpy(s.numero, gtk_entry_get_text(GTK_ENTRY(num2)));
strcpy(s.pw,gtk_entry_get_text(GTK_ENTRY(pw1)));
strcpy(s.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(role1)));
if (l==1)
strcpy(s.sex,"Homme");
else if (l==2)
strcpy(s.sex,"Femme");

ajouter(s);

}

void
on_validmodif_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *nom2, *prenom2, *cin2, *mail2, *adresse2, *sexe2, *num2, *spinbutton1,*pw2,*role2;
int c;
nom2 = lookup_widget (button , "nvnom");
prenom2 = lookup_widget (button , "nvprenom");
cin2 = lookup_widget (button , "nvcin");
mail2 = lookup_widget (button , "nvmail");
adresse2 = lookup_widget (button , "nvhuser");
sexe2 = lookup_widget (button , "combobox1");
num2 = lookup_widget (button , "nvnum");
spinbutton1=lookup_widget(button,"spinbutton2");
pw2=lookup_widget(button,"hpwmodif");
role2=lookup_widget(button,"modifier_role_combobox");


c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
sprintf(s.id,"%d",c);

strcpy(s.sex,gtk_combo_box_get_active_text(GTK_COMBO_BOX(sexe2)));

strcpy(s.nom, gtk_entry_get_text(GTK_ENTRY(nom2)));
strcpy(s.prenom, gtk_entry_get_text(GTK_ENTRY(prenom2)));
strcpy(s.cin, gtk_entry_get_text(GTK_ENTRY(cin2)));
strcpy(s.mail, gtk_entry_get_text(GTK_ENTRY(mail2)));
strcpy(s.user, gtk_entry_get_text(GTK_ENTRY(adresse2)));
strcpy(s.numero, gtk_entry_get_text(GTK_ENTRY(num2)));
strcpy(s.pw,gtk_entry_get_text(GTK_ENTRY(pw2)));
strcpy(s.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(role2)));
modifier(s);

}


void
on_validchercher_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
char ch[20];
GtkWidget *nomch, *prenomch, *cinch, *mailch, *adressech, *sexech, *numch, *idch,*pwch,*rolech;

idch=lookup_widget(button,"houschercher1");
nomch=lookup_widget(button,"houscherchernom");
prenomch=lookup_widget(button,"houschercherprenom");
sexech=lookup_widget(button,"houscherchersexe");
mailch=lookup_widget(button,"houscherchermail");
numch=lookup_widget(button,"houscherchernum");
adressech=lookup_widget(button,"houschercheradresse");
cinch=lookup_widget(button,"houscherchercin");
pwch=lookup_widget(button,"houscherchpw");
rolech=lookup_widget(button,"houscherchrole");
strcpy(ch, gtk_entry_get_text(GTK_ENTRY(idch)));
 FILE *fp;

    fp=fopen("hutilisateur.txt","a+");
    if(fp!=NULL)
        while(fscanf(fp,"%s %s %s %s %s %s %s %s %s %s \n",s.id,s.nom,s.prenom,s.sex,s.mail,s.numero,s.cin,s.user,s.pw,s.role)!=EOF)
 {
        if(strcmp(s.id,ch)==0)
	{
gtk_entry_set_text(idch,s.id);
gtk_entry_set_text(nomch,s.nom);
gtk_entry_set_text(prenomch,s.prenom);
gtk_entry_set_text(sexech,s.sex);
gtk_entry_set_text(mailch,s.mail);
gtk_entry_set_text(numch,s.numero);
gtk_entry_set_text(adressech,s.user);
gtk_entry_set_text(cinch,s.cin);
gtk_entry_set_text(pwch,s.pw);
gtk_entry_set_text(rolech,s.role);
  }	}
chercher(s);

}


void
on_validsupprimer_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

int c;
GtkWidget *spinbutton1;

spinbutton1=lookup_widget(button,"spinbutton4");

c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
sprintf(s.id,"%d",c);
supprimer(s);


}



void
on_retouraffiche_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowhous5;
windowhous5=create_gestion();
gtk_widget_show(windowhous5);
}


void
on_treeviewaffiche_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	
        utilisateur s;
	
	
	gchar id[20];
	gchar nom[20];
	gchar prenom[20];
	gchar sex[20];
	gchar mail[20];
	gchar numero[20];
	gchar user[20];
	gchar cin[20];
	gchar pw[20];
	gchar role[20];
	

	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&id,2,&nom,3,&prenom,4,&sex,5,&mail,6,&numero,7,&user,8,&cin,9,&pw,10,&role-1);

	
	strcpy(s.id,id);
	strcpy(s.nom,nom);
	strcpy(s.prenom,prenom);
	strcpy(s.sex,sex);
	strcpy(s.mail,mail);
	strcpy(s.numero,numero);
	strcpy(s.user,user);
	strcpy(s.cin,cin);
	strcpy(s.pw,pw);
	strcpy(s.role,role);
	
	
	

	afficher(treeview);
	}
}


void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
treeview=lookup_widget(button,"treeviewaffiche");
afficher(treeview);
}


void
on_pannedb_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windoww2;
windoww2=create_housfenetrepanne();
gtk_widget_show(windoww2);
windoww2=lookup_widget(windoww2,"htreeviewpanne");
rechercher(windoww2);
}


void
on_retourpanne_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowhous4;
windowhous4=create_gestion();
gtk_widget_show(windowhous4);
}


void
on_actualiserpanne_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
treeview=lookup_widget(button,"htreeviewpanne");
rechercher(treeview);
}


void
on_htreeviewpanne_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
					gpointer         user_data)
{
	
	debit d;
	gchar jour;
	gchar heure;
	gchar etage;
	gchar valeur;
	
	

	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&jour,2,&heure,3,&etage,4,&valeur,-1);

	
	strcpy(d.jour,jour);
	strcpy(d.heure,heure);
	strcpy(d.etage,etage);
	strcpy(d.vd,valeur);

	

	rechercher(treeview);
	}
}


void
on_hretourajout_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowhous;
windowhous=create_gestion();
gtk_widget_show(windowhous);
}


void
on_hretourmodif_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowhous1;
windowhous1=create_gestion();
gtk_widget_show(windowhous1);
}


void
on_houschretour_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowhous2;
windowhous2=create_gestion();
gtk_widget_show(windowhous2);
}


void
on_hretoursupp_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowhous3;
windowhous3=create_gestion();
gtk_widget_show(windowhous3);
}





void
on_hboutonfum_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *hwindoww3;
hwindoww3=create_pannefum();
gtk_widget_show(hwindoww3);
hwindoww3=lookup_widget(hwindoww3,"treeviewfum");
capfumee(hwindoww3);
}


void
on_treeviewfum_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
fumee fm;
	gchar jour1;
	gchar heure1;
	gchar numcapf;
	gchar valf;
	
	

	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&jour1,2,&heure1,3,&numcapf,4,&valf,-1);

	
	strcpy(fm.jour1,jour1);
	strcpy(fm.heure1,heure1);
	strcpy(fm.numcapf,numcapf);
	strcpy(fm.valf,valf);

	

	capfumee(treeview);
	}
}


void
on_retourfum_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowhous4;
windowhous4=create_gestion();
gtk_widget_show(windowhous4);
}


void
on_actualiserfum_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
treeview=lookup_widget(button,"treeviewfum");
capfumee(treeview);
}


void
on_hpannemvt_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *hwindoww4;
hwindoww4=create_pannemouv();
gtk_widget_show(hwindoww4);
hwindoww4=lookup_widget(hwindoww4,"treeviewpannemv");
capmouv(hwindoww4);
}



void
on_treeviewpannemv_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
mouvement mv;
	gchar jour2;
	gchar heure2;
	gchar numcapm;
	gchar valm;
	
	

	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&jour2,2,&heure2,3,&numcapm,4,&valm,-1);

	
	strcpy(mv.jour2,jour2);
	strcpy(mv.heure2,heure2);
	strcpy(mv.numcapm,numcapm);
	strcpy(mv.valm,valm);

	

	capmouv(treeview);
	}
}


void
on_retourpannemv_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowhous5;
windowhous5=create_gestion();
gtk_widget_show(windowhous5);

}


void
on_actualiserpannemv_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
treeview=lookup_widget(button,"treeviewpannemv");
capmouv(treeview);
}


void
on_hpannetemp_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *hwindoww5;
hwindoww5=create_pannetemp();
gtk_widget_show(hwindoww5);
hwindoww5=lookup_widget(hwindoww5,"treeviewpannetemp");
captemp(hwindoww5);
}


void
on_treeviewpannetemp_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	htemperature tm;
	gchar jour3;
	gchar heure3;
	gchar numcapt;
	gchar valt;
	
	

	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
	{
	
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,1,&jour3,2,&heure3,3,&numcapt,4,&valt,-1);

	
	strcpy(tm.jour3,jour3);
	strcpy(tm.heure3,heure3);
	strcpy(tm.numcapt,numcapt);
	strcpy(tm.valt,valt);

	

	captemp(treeview);
	}
}


void
on_actualiserpannetemp_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
treeview=lookup_widget(button,"treeviewpannetemp");
captemp(treeview);
}


void
on_retourpannetemp_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowhous6;
windowhous6=create_gestion();
gtk_widget_show(windowhous6);
}


void
on_hlogin_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}

