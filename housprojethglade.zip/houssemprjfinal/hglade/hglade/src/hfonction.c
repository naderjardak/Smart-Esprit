#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"hfonction.h"
#include <gtk/gtk.h>
#include"callbacks.h"

enum
{
	EID,
	ENOM,
	EPRENOM,
	ESEX,
	EMAIL,
	ENUMERO,
	EUSER,
	ECIN,
	EROLE,
	EPW,

	COLUMNS
};

enum
{
	EJOUR,
	EHEURE,
	EETAGE,
	EVD,
	COLUMNS1
};


enum
{
	EJOUR1,
	EHEURE1,
	ENMCAP,
	EVF1,
	COLUMNS2
};	
	
enum
{
	EJOUR2,
	EHEURE2,
	ENMCAP1,
	EVM,
	COLUMNS3
};

enum
{
	EJOUR3,
	EHEURE3,
	ENMCAPT,
	EVT,
	COLUMNS4
};		


void ajouter(utilisateur s)
{
        FILE *fp;

        fp=fopen("hutilisateur.txt","a+");

            
    if(fp!=NULL)
            fprintf(fp,"%s %s %s %s %s %s %s %s %s %s\n",s.id,s.nom,s.prenom,s.sex,s.mail,s.numero,s.cin,s.user,s.pw,s.role);


        fclose(fp);
}


void modifier(utilisateur nouv)
{
utilisateur s;
    FILE *fp, *fp1;

    fp=fopen("hutilisateur.txt","a+"); 
    fp1=fopen("temp.txt","a+");

    while(fscanf(fp,"%s %s %s %s %s %s %s %s %s %s\n",s.id,s.nom,s.prenom,s.sex,s.mail,s.numero,s.cin,s.user,s.pw,s.role)!=EOF)
    {printf("................");
        if(strcmp(s.id,nouv.id)==0)
	{
	    
            fprintf(fp1,"%s %s %s %s %s %s %s %s %s %s\n",nouv.id,nouv.nom,nouv.prenom,nouv.sex,nouv.mail,nouv.numero,nouv.cin,nouv.user,nouv.pw,nouv.role);
        }
else
        fprintf(fp1,"%s %s %s %s %s %s %s %s %s %s\n",s.id,s.nom,s.prenom,s.sex,s.mail,s.user,s.numero,s.cin,s.user,s.pw,s.role);
    }
	
    fclose(fp);
    fclose(fp1);
    remove("hutilisateur.txt");
    rename("temp.txt","hutilisateur.txt");
    }

void chercher(utilisateur n)
{
   FILE *fp;

    fp=fopen("hutilisateur.txt","a+");
    if(fp!=NULL)
        while(fscanf(fp,"%s %s %s %s %s %s %s %s %s %s\n",s.id,s.nom,s.prenom,s.sex,s.mail,s.numero,s.cin,s.user,s.pw,s.role)!=EOF)
        {
        if(strcmp(s.id,n.id)==0)
        {
	strcpy(n.id,s.id);
	strcpy(n.nom,s.nom);
	strcpy(n.prenom,s.prenom);
	strcpy(n.sex,s.sex);
	strcpy(n.mail,s.mail);
	strcpy(n.numero,s.numero);
	strcpy(n.cin,s.cin);
	strcpy(n.user,s.user);
	strcpy(n.pw,s.pw);
	strcpy(n.role,s.role);	 
        }
        }

    fclose(fp);
}

void supprimer(utilisateur n){
    int i=0;
    FILE *fp;
    FILE *fp1;

    fp=fopen("hutilisateur.txt","a+");
    fp1=fopen("temp.txt","w");

    if(fp!=NULL)
        while(fscanf(fp,"%s %s %s %s %s %s %s %s %s %s\n",s.id,s.nom,s.prenom,s.sex,s.mail,s.numero,s.cin,s.user,s.pw,s.role)!=EOF)
{
        if(strcmp(s.id,n.id)!=0){
         fprintf(fp1,"%s %s %s %s %s %s %s %s %s %s\n",s.id,s.nom,s.prenom,s.sex,s.mail,s.numero,s.cin,s.user,s.pw,s.role);
        }
    }
            fclose(fp);
            fclose(fp1);
            remove("hutilisateur.txt");
            rename("temp.txt","hutilisateur.txt");
    }

void afficher(GtkWidget *liste){
	 utilisateur s;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	
	GtkListStore *store;
	
	
   
	
	store=NULL;


	FILE *fp;


	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("sex",renderer,"text",ESEX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("mail",renderer,"text",EMAIL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("numero",renderer,"text",ENUMERO,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",ECIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("username",renderer,"text",EUSER,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Password",renderer,"text",EPW,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Role",renderer,"text",EROLE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);



        
        fp = fopen("hutilisateur.txt","r");
        if (fp==NULL)
	return (0);
        else
            while(fscanf(fp,"%s %s %s %s %s %s %s %s %s %s\n",s.id,s.nom,s.prenom,s.sex,s.mail,s.numero,s.cin,s.user,s.pw,s.role)!=EOF)
	{
            
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EID,s.id,ENOM,s.nom,EPRENOM,s.prenom,ESEX,s.sex,EMAIL,s.mail,ENUMERO,s.numero,ECIN,s.cin,EUSER,s.user,EPW,s.pw,EROLE,s.role,-1);
        }
        fclose(fp);
	}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
}
      

void rechercher(GtkWidget *liste){
    
    FILE *fp;
    

	debit d;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	
	GtkListStore *store;
	store=NULL;
	store=gtk_tree_view_get_model(liste);
	
	float x;
	if(store==NULL)
	{

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("heure",renderer,"text",EHEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",EETAGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("valeur",renderer,"text",EVD,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	store=gtk_list_store_new (COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	fp = fopen("debit.txt","r");
	
	if (fp==NULL)
	return (0);
	
	else				
    while (fscanf(fp,"%s %s %s %s\n",d.jour,d.heure,d.etage,d.vd)!=EOF) 
{
	x=atof(d.vd);
	if (x>30 || x<0){				
        gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EJOUR,d.jour,EHEURE,d.heure,EETAGE,d.etage,EVD,d.vd,-1);
        }
}
   	fclose(fp);
}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);						

}


void capfumee (GtkWidget *liste){
  FILE *fpf;
    

	fumee fm;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	
	GtkListStore *store;
	store=NULL;
	store=gtk_tree_view_get_model(liste);
	
	int y;
	int u;
	if(store==NULL)
	{

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJOUR1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("heure",renderer,"text",EHEURE1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("numero du cap",renderer,"text",ENMCAP,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("valeur",renderer,"text",EVF1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	store=gtk_list_store_new (COLUMNS2,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	fpf = fopen("fumee.txt","r");
	
	if (fpf==NULL)
	return (0);
	
	else				
    while (fscanf(fpf,"%s %s %s %s\n",fm.jour1,fm.heure1,fm.numcapf,fm.valf)!=EOF) 
{
	y=atoi(fm.valf);
	u=atoi(fm.heure1);
	if ((y>0)&&(u>0)&&(u<7)){				
        gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EJOUR1,fm.jour1,EHEURE1,fm.heure1,ENMCAP,fm.numcapf,EVF1,fm.valf,-1);
        }
}
   	fclose(fpf);
}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);						

}


void capmouv (GtkWidget *liste)
{
  FILE *fpm;
    

	mouvement mv;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	
	GtkListStore *store;
	store=NULL;
	store=gtk_tree_view_get_model(liste);
	
	int v;
	if(store==NULL)
	{

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJOUR2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("heure",renderer,"text",EHEURE2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("numero du cap",renderer,"text",ENMCAP1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("valeur",renderer,"text",EVM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	store=gtk_list_store_new (COLUMNS3,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	fpm = fopen("mouvement.txt","r");
	
	if (fpm==NULL)
	return (0);
	
	else				
    while (fscanf(fpm,"%s %s %s %s\n",mv.jour2,mv.heure2,mv.numcapm,mv.valm)!=EOF) 
{
	v=atoi(mv.valm);
	if (v>0){				
        gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EJOUR2,mv.jour2,EHEURE2,mv.heure2,ENMCAP1,mv.numcapm,EVM,mv.valm,-1);
        }
}
   	fclose(fpm);
}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);						

}

void captemp (GtkWidget *liste){
  FILE *fpt;
    

	htemperature tm;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	
	GtkListStore *store;
	store=NULL;
	store=gtk_tree_view_get_model(liste);
	
	float celcus;
	if(store==NULL)
	{

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJOUR3,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("heure",renderer,"text",EHEURE3,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("numero du cap",renderer,"text",ENMCAPT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("valeur de temperature",renderer,"text",EVT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	store=gtk_list_store_new (COLUMNS4,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	fpt = fopen("temperature.txt","r");
	
	if (fpt==NULL)
	return (0);
	
	else				
    while (fscanf(fpt,"%s %s %s %s\n",tm.jour3,tm.heure3,tm.numcapt,tm.valt)!=EOF) 
{
	celcus=atof(tm.valt);
	if (celcus>30 || celcus<10){				
        gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,EJOUR3,tm.jour3,EHEURE3,tm.heure3,ENMCAPT,tm.numcapt,EVT,tm.valt,-1);
        }
}
   	fclose(fpt);
}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);						

}




