#ifndef _hfonction_h
#define _hfonction_h
#include <gtk/gtk.h>
typedef struct {
    char id[50];
    char nom[50];
    char prenom[50];
    char sex[50];
    char mail[50];
    char numero[8];
    char user[30];
    char pw[50];
    char cin[20];
    char role[40];
}utilisateur;
utilisateur s;

GtkTreeIter iter;
GtkWidget *liste;


typedef struct {
    char jour[10]; 
    char heure[10];
    char etage[10];
    char vd[10]; 
}debit;
debit d;


typedef struct {
    char jour1[10]; 
    char heure1[10];
    char numcapf[10];
    char valf[10]; 
}fumee;
fumee fm;


typedef struct {
    char jour2[10]; 
    char heure2[10];
    char numcapm[10];
    char valm[10]; 
}mouvement;
mouvement mv;

typedef struct {
    char jour3[10]; 
    char heure3[10];
    char numcapt[10];
    char valt[10]; 
}htemperature;
 htemperature tm;

char id1[20];

void ajouter(utilisateur s);
void modifier(utilisateur nouv);
void chercher(utilisateur s);
void supprimer(utilisateur s);
void afficher(GtkWidget *liste);
void rechercher (GtkWidget *liste);
void capfumee (GtkWidget *liste);
void capmouv (GtkWidget *liste);
void captemp (GtkWidget *liste);
#endif
