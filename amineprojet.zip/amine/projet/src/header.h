#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct {
char nom [20];
char prenom [20];
char id [8];
char nom_service[20];
char motif[20];
}rec;




//fonction part1
void introduire_reclamation(rec reclamation, char file[]);
//void modifier_reclamation(rec reclamation,char file[]);
//void supprimer_reclamation(char id, rec reclamation,char file[] );
//fonction part2
//rec chercher_reclamation(char id,rec reclamation,char file[]);
#endif
