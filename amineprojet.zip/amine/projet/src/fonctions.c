
#include "header.h"
#include <string.h>

void introduire_reclamation(rec r,char file[])
{
	FILE *f;
    f=fopen(file,"a+");
   
printf("donner nom");
	scanf("%s",r.nom);
printf("donner prenom");
	scanf("%s",r.prenom);
printf("donner id");
        scanf("%s",r.id);
printf("donner le nom du service");
	scanf("%s",r.nom_service);
printf("donner le motif");
	scanf("%s",r.motif);
if (f!=NULL)
{
    fprintf(f,"%s %s %s %s %s\n",r.nom,r.prenom,r.id,r.nom_service,r.motif);
	fclose(f);
}
}

void modifier_reclamation(rec reclamation,char file[])
{
	int d=0,j,id,x=0,choix,nouv_id;
	FILE *f;
	char c[400];
	char newNom[20];
	char newPrenom[20];
	char newMotif[20];
	char newNomService[20];
printf ("donner id pour modifier \n");
scanf("%d",&id);
	f=fopen("filel.txt","r+");
while ((c==fgetc(f)) !=EOF)
{ if (c == '\n')
	d++;
}

    fclose(f);
    f=fopen("filel.txt","r");
for (j=0;j<d;j++)
{fscanf(f,"%s %s %s %s \n",reclamation.nom,reclamation.prenom,reclamation.motif,reclamation.id);
if (strcmp(id,reclamation.id))
x=reclamation.id;
}
fclose(f);
if (strcmp(x,id))
{
do {

printf ("cquoi le changement");
printf ("1-NOM \n 2-PRENOM \n 3-MOTIF \n");
scanf("%d",&choix);
switch(choix)
{
case 1:
	printf("NOUVEAU NOM");
	scanf ("%s", newNom);
for (j=0;j<d;j++)
{
if (strcmp(x,reclamation.id))
{
strcpy(reclamation.nom,newNom);
}
}
break;
case 2:
	printf("NOUVEAU PRENOM:");
	scanf("%s",newPrenom);
for (j=0;j<d;j++)
{
if (strcmp(x,reclamation.id))
{ 
strcpy (reclamation.prenom,newPrenom);
}
}
break;
case 3:
	printf("NOUVEAU MOTIF");
	scanf("%s",newMotif);
for (j=0;j<d;j++)
{
if (strcmp(x,reclamation.id))
{
strcpy(reclamation.motif,newMotif);
}
}
break;
}
}while ((choix<2)||(choix>4));
f=fopen("filel.txt","w");
for (j=0;j<d;j++)
{
fprintf(f, "%s %s %s %s",reclamation.nom,reclamation.prenom,reclamation.motif,reclamation.id);
}
fclose(f);
}
else printf("id n existe pas");

}

void supprimer_reclamation(char id,rec r,char file[])
{
    FILE *f;
    FILE *f1;
   
    f=fopen(file,"r");
    f1=fopen("aux.txt","a+");
    while (fscanf(f,"%s %s %s %s %s",r.nom,r.prenom,r.id,r.nom_service,r.motif)!=EOF)
    {
        if(!strcmp(r.id,id))
            {    
                fprintf(f1,"%s %s %s %s %s",r.nom,r.prenom,r.id,r.nom_service,r.motif);
            }
    }

    fclose(f);
    fclose(f1);
    remove(file);
    rename("aux.txt",file);

}


rec chercher_reclamation(char id,rec r,char file[])
{
	FILE *f;
   
    f=fopen(file,"r");
    while (fscanf(f,"%s %s %s %s %s",r.nom,r.prenom,r.id,r.nom_service,r.motif)!=EOF)
        {
             if(strcmp(r.id,id))
                {
                    fclose(f);
                    return r;
                }       
        }    
}


