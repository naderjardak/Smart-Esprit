#include <gtk/gtk.h>


void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_modif_enregistrer_clicked           (GtkWidget       *widget,
                                        gpointer         user_data);


void
on_modif_id_changed                    (GtkWidget     *widget,
                                        gpointer         user_data);

void
on_modif_afficher_clicked              (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_button_reclamer_clicked             (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkWidget      *widget,
                                        gpointer         user_data);

void
on_button1_cher_clicked                (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_checkbutton1_resto_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_heberg_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_aminretrec_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonplusrec_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_aminservicerec_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_retplusrec_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
