#include "user.h"



enum
{
	ENOM,
	EPRENOM,
	EIDENTIFIANT,
	ESEXE,
	ENOM_DU_SERVICE,
	EMOTIF,
	COLUMNS
	
}
;


void introduire_reclamation(rec r)
{
	FILE *f; 
	f=fopen("file.txt","a+");
if (f==NULL)
{return ;
}
else
{
fprintf(f,"%s %s %s %s %s %s \n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif);
}
fclose(f);
}





///////////////////////////////////////////////
void modifier_reclamation(rec r1)
{
rec r;
FILE *f,*g;
f=fopen("file.txt","r");
g=fopen("file2.txt","w+");
if ((f==NULL)	||	(g==NULL))
{
return;
}
else
{
	while (fscanf(f,"%s %s %s %s %s %s\n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif)!=EOF)	
		{
			if(strcmp(r1.identifiant,r.identifiant)==0)
			{fprintf(g,"%s %s %s %s %s %s\n",r.nom,r.prenom,r1.identifiant,r.sexe,r1.nom_service,r1.motif);
			}
			else
			{
				
			fprintf(g,"%s %s %s %s %s %s\n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif);

			}

}
}
		fclose(f);
		fclose(g);
remove("file.txt");
rename("file2.txt","file.txt");
}

///////////////////////////////////////////////
void supprimer_reclamation(char id [] )
{
	
	rec r;
	FILE *f, *g;
	f=fopen("file.txt","r");
	g=fopen("file2.txt","w+");

	if (f==NULL	||	g==NULL)
	{
		return;
	}
	else
	{
		while (fscanf(f,"%s %s %s %s %s %s\n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif)!=EOF)
		{
			if(strcmp(r.identifiant,id)!=0)
			fprintf(g,"%s %s %s %s %s %s\n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif);
		}
		fclose(f);
		fclose(g);
remove("file.txt");
rename("file2.txt","file.txt");
	}
}
///////////////////////////////////////////////
rec chercher_reclamation(char id [])
{
	rec r;
	FILE *f, *g;
	f=fopen("file.txt","r");
	g=fopen ("tmp.txt","a+");

	if (f==NULL)
	{
		return;
	}
	else
	{
		while (fscanf(f,"%s %s %s %s %s %s\n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif)!=EOF)
		{
			if(strcmp(r.identifiant,id)==0)
			{
			fscanf(g,"%s %s %s %s %s %s\n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif);
			return r;
			}
		}
		fclose(f);

	}
}


///////////////////////////////////////////////
void afficher(GtkWidget *liste)
{
	FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	rec r;
	char nom[30];
	char prenom [30];
	char identifiant[8];
	char sexe[10];
	char nom_service[15];
	char motif[255];
	
	store=NULL;		
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
{ 

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom_service",renderer,"text",ENOM_DU_SERVICE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("motif",renderer,"text",EMOTIF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
}
store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("file.txt","r");
	if(f==NULL)
{

	return;
}
	else
{
	
	while (fscanf(f,"%s %s %s %s %s %s \n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif)!=EOF)
{
		gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,ENOM,r.nom,EPRENOM,r.prenom,EIDENTIFIANT,r.identifiant,ESEXE,r.sexe,ENOM_DU_SERVICE,r.nom_service,EMOTIF,r.motif, -1);

}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//////////////////////////////////////////////////////////////////////////////////
void afficher_cher(GtkWidget *liste)
{
	FILE *g;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
rec r;
	char nom[30];
	char prenom [30];
	char identifiant[8];
	char sexe[10];
	char nom_service[15];
	char motif[255];
	
	store=NULL;		
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
{ 

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom_service",renderer,"text",ENOM_DU_SERVICE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("motif",renderer,"text",EMOTIF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
}
store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	g=fopen("tmp.txt","r");
	if(g==NULL)
{

	return;
}
	else
{
	
	while (fscanf(g,"%s %s %s %s %s %s \n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif)!=EOF)
{
		gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,ENOM,r.nom,EPRENOM,r.prenom,EIDENTIFIANT,r.identifiant,ESEXE,r.sexe,ENOM_DU_SERVICE,r.nom_service,EMOTIF,r.motif, -1);
}
fclose(g);
}
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
















///////////////////////////////////////////////

void afficher1(char id[],GtkWidget *liste)
{
	FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	rec r;
	char nom[30];
	char prenom [30];
	char identifiant[8];
	char sexe[10];
	char nom_service[15];
	char motif[255];
	
	store=NULL;		
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
{ 

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom_service",renderer,"text",ENOM_DU_SERVICE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("motif",renderer,"text",EMOTIF,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
}
store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("file.txt","r");
	if(f==NULL)
{

	return;
}
	else
{
	
	while (fscanf(f,"%s %s %s %s %s %s \n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif)!=EOF)
{ 
           if(strcmp(r.identifiant,id)==0)
{
		gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,ENOM,r.nom,EPRENOM,r.prenom,EIDENTIFIANT,r.identifiant,ESEXE,r.sexe,ENOM_DU_SERVICE,r.nom_service,EMOTIF,r.motif, -1);
}
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}


