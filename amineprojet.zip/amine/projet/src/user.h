

#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include<gtk/gtk.h>

typedef struct {
char nom[30];
char prenom [30];
char identifiant[8];
char sexe[10];
char nom_service[15];
char motif[255];
} rec;
rec r;

char id[30];
//fonction part1
void afficher1(char id[],GtkWidget *liste);
void introduire_reclamation(rec r);
void modifier_reclamation(rec r);
void supprimer_reclamation(char id []);
//fonction part2
rec chercher_reclamation(char id []);
void afficher_cher(GtkWidget *liste);
void afficher(GtkWidget *liste);
rec cher_reclamation(char id );


#endif
