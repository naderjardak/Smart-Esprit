#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "user.h"


void 
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_button_ajouter_clicked              (GtkWidget       *widget,
                                        gpointer         user_data)
{

GtkWidget *nom, *prenom, *identifiant, *nomservice, *motif, *homme, *femme;
rec r;
nom=lookup_widget (widget,"entry_nom");
prenom=lookup_widget (widget,"entryprenom");
identifiant=lookup_widget (widget,"entry3");
motif=lookup_widget (widget,"entry_motif");
homme=lookup_widget(widget,"radiobutton_homme");
femme=lookup_widget(widget,"radiobutton_femme");
nomservice=lookup_widget(widget,"combobox1");
strcpy(r.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(r.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
 strcpy(r.identifiant, gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(r.motif, gtk_entry_get_text(GTK_ENTRY(motif)));
strcpy(r.nom_service, gtk_combo_box_get_active_text(GTK_COMBO_BOX(nomservice)));
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(homme)))
	{
		strcpy(r.sexe,"Homme");		
	}
	else
	{
		strcpy(r.sexe,"Femme");	
	}

introduire_reclamation(r);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *nom;
gchar *prenom;
gchar *identifiant;
gchar *sexe;
gchar *nom_service;
gchar *motif;
rec r;
gchar id;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter, path))
{
gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&nom,1,&prenom,2,&identifiant,3,&sexe,4,&nom_service,5,&motif,-1);

strcpy(r.nom,nom);
strcpy(r.prenom,prenom);
strcpy(r.identifiant,identifiant);
strcpy(r.sexe,sexe);
strcpy(r.nom_service,nom_service);
strcpy(r.motif,motif);

supprimer_reclamation(id);

afficher(model); 
}
}


void
on_retour_clicked                      (GtkWidget       *widget,
                                        gpointer         user_data)
{

GtkWidget *treeview1,*fenetre ;
fenetre=lookup_widget(widget,"Affichage");

treeview1=lookup_widget(fenetre,"treeview1");
afficher(treeview1);

}


void
on_modif_enregistrer_clicked           (GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget  *identifiant, *nomservice, *motif;
rec r;

FILE *f,*g;
f=fopen("file.txt","r");

identifiant=lookup_widget (widget,"modif_id");
motif=lookup_widget (widget,"modif_nomservice");
nomservice=lookup_widget(widget,"modif_motif");

strcpy(r.identifiant, gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(r.motif, gtk_entry_get_text(GTK_ENTRY(nomservice)));
g=fopen("file5.txt","w+");
strcpy(r.nom_service, gtk_combo_box_get_active_text(GTK_COMBO_BOX(motif)));

	modifier_reclamation(r);

}



void
on_modif_id_changed                    (GtkWidget     *widget,
                                        gpointer         user_data)
{


}


void
on_modif_afficher_clicked              (GtkWidget       *widget,
                                        gpointer         user_data)
{
/*GtkWidget *treeview1,*fenetre , *modif;
modif=lookup_widget(widget,"Modification");
gtk_widget_destroy(modif);
fenetre=lookup_widget(widget,"Affichage");
fenetre=create_Modification ();
gtk_widget_show(fenetre);
treeview1=lookup_widget(fenetre,"treeview1");
afficher(treeview1);
*/
GtkWidget *amineretaffich;
amineretaffich=create_Affichage();
gtk_widget_show(amineretaffich);
}


void
on_button_modifier_clicked             (GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget  *Modification;
Modification=create_Modification();
gtk_widget_show(Modification);
}


void
on_button_reclamer_clicked             (GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget  *reclamation;
reclamation=lookup_widget(widget,"reclamation");
reclamation=create_reclamation();
gtk_widget_show(reclamation);
}


void
on_button_supprimer_clicked            (GtkWidget       *widget,
                                        gpointer         user_data)
{
char id[50];
GtkWidget  *supprimer;
supprimer=lookup_widget(widget,"entry_id_sup");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(supprimer)));
supprimer_reclamation(id );

}


void
on_button1_cher_clicked                (GtkWidget       *widget ,
                                        gpointer         user_data)
{
rec a;
GtkWidget  *chercher, *fenetre, *treeview1;
chercher=lookup_widget(widget,"entry4_cher");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(chercher)));
fenetre=lookup_widget(widget,"Affichage");
treeview1=lookup_widget(fenetre,"treeview1");
afficher1(id,treeview1);
}


void
on_checkbutton1_resto_toggled          (GtkToggleButton *objet,
                                        gpointer         user_data)
{
/*int tab[2]={0,0};
GtkWidget *togglebutton1, *togglebutton2;
GtkWidget *output;
output=lookup_widget(objet,"label2");
togglebutton1=lookup_widget(objet,"checkbutton1");
togglebutton2=lookup_widget(objet,"checkbutton2");
	if (tab[0]==1)
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton1), TRUE);
	if (tab[0]==1)
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(togglebutton2), TRUE);
gtk_label_set_text(GTK_LABEL(output));
*/
}


void
on_checkbutton2_heberg_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_aminretrec_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *recl;
recl=create_Affichage();
gtk_widget_show(recl);
}


void
on_buttonplusrec_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *plus;
int H=0;
int R=0;
plus=lookup_widget(button,"servcplusrec");
FILE *f;

  f=fopen("file.txt","a+"); 
while (fscanf(f,"%s %s %s %s %s %s \n",r.nom,r.prenom,r.identifiant,r.sexe,r.nom_service,r.motif)!=EOF)
{ 
	if(strcmp(r.nom_service,"Hebergement"))
		H++;
	if(strcmp(r.nom_service,"Restauration"))
		R++;
}
	if(H>R)
	gtk_entry_set_text(plus,"Le service Hebergement est le plus reclammé");
		else if(R>H)
			gtk_entry_set_text(plus,"Le service Restauration est le plus reclammé");
				else
				gtk_entry_set_text(plus,"les recmlammations sur les deux services sont egeaux");
}


void
on_aminservicerec_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *plsrec;
plsrec=create_servplusrec();
gtk_widget_show(plsrec);
}


void
on_retplusrec_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *retpl;
retpl=create_Affichage();
gtk_widget_show(retpl);
}

